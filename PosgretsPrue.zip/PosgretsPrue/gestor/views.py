from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime 

def inicio(request):
    contexto={}
    return render(request, 'inicio.html', contexto)

def formulario(request):
    return render(request, "formulario.html")

def respuesta(request):
    agnoaActual=datetime.now().year
    diaActual=datetime.now().day
    mesActual=datetime.now().month
    agnoNacimiento=int(request.GET["nacimiento"].split('-')[0])
    mesNacimiento=int(request.GET["nacimiento"].split('-')[1])
    diaNacimiento=int(request.GET["nacimiento"].split('-')[2])

    edad=agnoaActual - agnoNacimiento
    if mesNacimiento > mesActual:
        edad-=1
    elif mesActual==mesNacimiento:
        if diaActual < diaNacimiento:
            edad=-1

    nombre=request.GET["nombre"]
    genero=request.GET["genero"]
    return render(request, 'respu.html', {'nombre':nombre, 'edad':edad, 'genero':genero})