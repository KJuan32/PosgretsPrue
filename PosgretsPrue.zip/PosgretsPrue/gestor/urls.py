from django.urls import path  
from .import views


ulrpatterns = [
    path('', views.inicio, name='inicio'),
    path('formulario/', views.formulario),
    path('respuesta/', views.respuesta),
]
